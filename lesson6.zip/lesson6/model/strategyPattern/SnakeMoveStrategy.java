package model.strategyPattern;

public interface SnakeMoveStrategy {
    void moveAlgorithm();    
}
